/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;
import java.util.List;
import java.util.LinkedList;

public class BruteCollinearPoints {
    private LineSegment[] segments;

    public BruteCollinearPoints(Point[] points) {
        if (points == null) throw new java.lang.NullPointerException("points is null in constructor");

        checkNullEntries(points);
        Point[] sortedPoints = points.clone();
        Arrays.sort(sortedPoints);


        checkDuplicatedEntries(sortedPoints);

        final int N = points.length;
        List<LineSegment> list = new LinkedList<>();

        for (int i = 0; i < points.length; i++) {
            Point pointI = sortedPoints[i];

            for (int j = i + 1; j < points.length - 2; j++) {
                Point pointJ = sortedPoints[j];
                double slopeIJ = pointI.slopeTo(pointJ);

                for (int k = j + 1; k < points.length - 1; k++) {
                    Point pointK = sortedPoints[k];
                    double slopeIK = pointI.slopeTo(pointK);
                    if (slopeIJ == slopeIK) {

                        for (int l = k + 1; l < points.length; l++) {
                            Point pointL = sortedPoints[l];
                            double slopeIL = pointI.slopeTo(pointL);
                            if (slopeIJ == slopeIL) {
                                LineSegment tempLine = new LineSegment(pointI, pointL);
                                if (!list.contains(tempLine)) list.add(tempLine);
                            }
                        }
                    }
                }
            }
        }
        segments = list.toArray(new LineSegment[0]);

    }

    public int numberOfSegments() {
        return segments.length;
    }

    public LineSegment[] segments() {
        return segments.clone();
    }

    private void checkNullEntries(Point[] points) {
        for (int i = 0; i < points.length; i++)
        {
            if (points[i] == null) throw new java.lang.NullPointerException();
        }
    }

    private void checkDuplicatedEntries(Point[] points) {
        for (int i = 0; i < points.length -1; i++)
        {
            if (points[i].compareTo(points[i + 1]) == 0)
                throw new java.lang.IllegalArgumentException("Duplicated entries in given points");
        }

    }


    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }

}
